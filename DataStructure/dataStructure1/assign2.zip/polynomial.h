// CSE221 Assignment 2
//Student Number: 20131674
//Student Name :   Jeong  Wan Gho

#ifndef polynomial_h
#define polynomial_h

#include <typeinfo>
#include <iostream>
#include <math.h>

template <typename T>
class Polynomial
{
private:
	int degree;
	T *coef;

public:
	// Default constructor p(x) = 0
	Polynomial();

	 // Constructor p(x) = 0*x^degr
	Polynomial(int degr);

	// Copy constructor
	Polynomial(const Polynomial& source);

	// Destructor
	~Polynomial();

	// Assignment operator
	Polynomial& operator = (const Polynomial& source);

	// Sum of *this and source polynomials
	Polynomial operator+(const Polynomial& source);

	// Subtract of source polynomials from *this
	Polynomial operator-(const Polynomial& source);

	// Product of *this and source polynomials
	Polynomial operator*(const Polynomial& source);

	// Evaluate polynomial *this at x and return the result
	T Eval(T x);

	// Print polynomial
	void Print();

	// Create a new term. If the term exists, overwrite its coefficient.
	void CreateTerm(const T coef, const int exp);

	//Get the value of degree
	int getDegree() const;

	//Get the pointer coef
	T* getCoef() const;

};

//
// Implementation
//


// Default constructor p(x) = 0
template <typename T>
Polynomial<T>::Polynomial()
{
	degree=0;
	coef=new T[degree+1];
	coef[0]=0;
}

// Constructor p(x) = 0*x^degr
template <typename T>
Polynomial<T>::Polynomial(int degr)
{
    degree=degr;
    coef=new T[degree+1];
    for (int i=0; i<=degree; i++) coef[i]=0;
}


// Copy constructor
template <typename T>
Polynomial<T>::Polynomial(const Polynomial& source)
{
    degree=source.getDegree();

    if(degree>=0){
        coef=new T[degree+1];
        for (int i=0; i<degree+1; i++){
            coef[i]=source.getCoef()[i];
        }
    }
}

//Assignment operator
template <typename T>
Polynomial<T>& Polynomial<T>::operator = (const Polynomial& source)
{
    if (this==&source) return *this;

    if (degree>=0){
        delete[] coef;
        degree=-1;
    }

    degree=source.getDegree();//same as copy-constructor
    if(degree>=0){
        coef=new T[degree+1];
        for (int i=0; i<degree+1; i++){
            coef[i]=source.getCoef()[i];
        }
    }
    return *this;
}

//Destructor
template <typename T>
Polynomial<T>::~Polynomial()
{
    if(degree>=0) delete[] coef;
}

//Print Polynomial in descending order
template <typename T>
void Polynomial<T>::Print()
{
    for(int i=0; i<degree+1; i++){
        if(coef[degree-i]==0) continue;//remove the zero coefficient terms
        if(coef[degree-i]>0 && i>0) std::cout<<"+";
        std::cout<<coef[degree-i];
        if(degree-i>0)    std::cout<<"x^"<<degree-i; 
    }       
    std::cout<<std::endl;
}

// Sum of *this and source polynomials
template <typename T>
Polynomial<T>
Polynomial<T>::operator+(const Polynomial& source)
{
    Polynomial temp;
    T* tempCoef;
    T* thisCoef=this->getCoef();
    T* sourceCoef=source.getCoef();
    int thisdegree=this->getDegree();
    int sourcedegree=source.getDegree();

    if(thisdegree>sourcedegree){
        temp=Polynomial(thisdegree);
    }
    else{
        temp=Polynomial(sourcedegree);
    }//create memory space for storing
    tempCoef=temp.getCoef();

    for (int i=0; i<thisdegree+1; i++){
        tempCoef[i]+=thisCoef[i];
    }
    for (int i=0; i<sourcedegree+1; i++){
        tempCoef[i]+=sourceCoef[i];
    }
    return temp;
}

// Subtract of source polynomials from *this
template <typename T>
Polynomial<T>
Polynomial<T>::operator-(const Polynomial& source)
{
    Polynomial temp;
    T* tempCoef;
    T* thisCoef=this->getCoef();
    T* sourceCoef=source.getCoef();
    int thisdegree=this->getDegree();
    int sourcedegree=source.getDegree();

    if(thisdegree>sourcedegree){
        temp=Polynomial(thisdegree);
    }
    else{
        temp=Polynomial(sourcedegree);
    }
    tempCoef=temp.getCoef();

    for (int i=0; i<thisdegree+1; i++){
        tempCoef[i]+=thisCoef[i];
    }
    for (int i=0; i<sourcedegree+1; i++){
        tempCoef[i]-=sourceCoef[i];
    }// just same as operator +
    return temp;
}

// Product of *this and source polynomials
template <typename T>
Polynomial<T>
Polynomial<T>::operator*(const Polynomial& source)
{
    Polynomial temp;
    T* tempCoef;
    T* thisCoef=this->getCoef();
    T* sourceCoef=source.getCoef();
    int thisdegree=this->getDegree();
    int sourcedegree=source.getDegree();

    temp=Polynomial(thisdegree+sourcedegree);//create memory space for storage
    tempCoef=temp.getCoef();

    for (int i=0; i<thisdegree+1; i++){
        for (int j=0; j<sourcedegree+1; j++){
            tempCoef[i+j]+=thisCoef[i]*sourceCoef[j];
        }//multiply and sum every possible terms
    }
    return temp;
}

// Evaluate polynomial *this at x and return the result
template <typename T>
T Polynomial<T>::Eval(T x)
{
    T temp;
    T tempPoly;

    for (int i=0; i<degree+1; i++){
        tempPoly=1;
        for(int j=0; j<i; j++){
            tempPoly*=x;
        }
        temp+=coef[i]*tempPoly;
    }
    return temp;
}

// Create a new term. If the term exists, overwrite its coefficient.
template <typename T>
void Polynomial<T>::CreateTerm(const T coef, const int exp)
{
    if(degree>=exp){
        this->coef[exp]=coef;
    }
    else{
        Polynomial temp(exp);
        for(int i=0; i<degree+1; i++){
            temp.getCoef()[i]=this->coef[i];
        }
        temp.coef[exp]=coef;
        *this=temp;
        degree=exp;
    }
}

//Get the value of degree
template <typename T>
int Polynomial<T>::getDegree() const
{
	return degree;
}

//Get the pointer coef
template <typename T>
T* Polynomial<T>::getCoef() const
{
    return coef;
}


#endif


