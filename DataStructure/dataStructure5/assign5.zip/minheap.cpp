#include "minheap.h"

/** 
 * Assignment 5 for CSE221 Data Structures
 *
 * 2015. 11. 2
 *
 */


// Destructor
MinHeap::~MinHeap()
{
	// ToDo
	delete[] heapArray;
	delete[] mapVidxToArray;
}


void 
MinHeap::Push(const heapElem& e)
{
	// ToDo
	size++;
	unsigned int i;
	//Bubbling up
	for(i=size; true;){
		if(i==1) break; // Root reached
		if (e.dist >= heapArray[i/2].dist) break;
		//move parent down
		heapArray[i].vidx=heapArray[i/2].vidx;
		heapArray[i].dist=heapArray[i/2].dist;
		mapVidxToArray[heapArray[i].vidx]=i;
		i/=2;
	}
	heapArray[i].vidx=e.vidx;
	heapArray[i].dist=e.dist;
	mapVidxToArray[heapArray[i].vidx]=i;
}


const heapElem & 
MinHeap::Top()
{
	// ToDo
	return heapArray[1];	
}


void 
MinHeap::Pop()
{	
	// ToDo
	if( IsInHeap( heapArray[1] ) ){ // if the heap is not empty
		heapElem lastE;
		lastE.vidx=heapArray[size].vidx;
		lastE.dist=heapArray[size].dist;
		mapVidxToArray[ heapArray[size].vidx ]=0;
		size--; //remove last element from heap

		//trickle down
		unsigned int currentNode=1; // root
		unsigned int child=2; // a child of currentNode
		while(child<=size){
			//set child to smaller child of currentNode
			if(child<size && heapArray[child].dist>heapArray[child+1].dist)
				child++;
			//can we put lastE in currentNode?
			if(lastE.dist <= heapArray[child].dist) break; //yes
			//no
				//move child up
			heapArray[currentNode].vidx=heapArray[child].vidx;
			heapArray[currentNode].dist=heapArray[child].dist;
			mapVidxToArray[heapArray[currentNode].vidx]=currentNode;
				//move down a level
			currentNode=child;
			child*=2;			
		}
		heapArray[currentNode].vidx=lastE.vidx;
		heapArray[currentNode].dist=lastE.dist;
		mapVidxToArray[heapArray[currentNode].vidx]=currentNode;
	}
	else{
		printf("Heap is empty. Cannot delete");
	}
}


void MinHeap::Modify(const heapElem& e)
{
	// ToDo

	//delete the element in heapArray which has the same key value as e
	//then push e as a new element

	 // consider e as a root of the subtree
	unsigned int currentNode=mapVidxToArray[e.vidx];
	unsigned int child=2*currentNode; // a child of currentNode

	if( IsInHeap( heapArray[currentNode] ) ){ //if the subtree is not empty
		heapElem lastE;
		lastE.vidx=heapArray[size].vidx;
		lastE.dist=heapArray[size].dist;
		mapVidxToArray[ heapArray[size].vidx ]=0;
		size--; //remove last element from heap

		//trickle down
		while(child<=size){
			//set child to smaller child of currentNode
			if(child<size && heapArray[child].dist>heapArray[child+1].dist)
				child++;
			//can we put lastE in currentNode?
			if(lastE.dist <= heapArray[child].dist) break; //yes
			//no
				//move child up
			heapArray[currentNode].vidx=heapArray[child].vidx;
			heapArray[currentNode].dist=heapArray[child].dist;
			mapVidxToArray[heapArray[currentNode].vidx]=currentNode;
				//move down a level
			currentNode=child;
			child*=2;			
		}
		heapArray[currentNode].vidx=lastE.vidx;
		heapArray[currentNode].dist=lastE.dist;
		mapVidxToArray[heapArray[currentNode].vidx]=currentNode;
	}

	//push the e
	Push(e);
}


bool MinHeap::IsEmpty()
{
	// ToDo
	if(size>0) return false;
	else return true;	
}
